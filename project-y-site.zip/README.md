# Project Y website

This folder contains the three public pages needed for the Oura developer application:

- `index.html` — Website
- `privacy.html` — Privacy Policy
- `terms.html` — Terms of Service

## Before publishing

Replace every occurrence of `YOUR_EMAIL@example.com` with the same contact email address you enter in the Oura developer portal.

## GitHub Pages

1. Create a public GitHub repository, for example `project-y`.
2. Upload all four website files from this folder: `index.html`, `privacy.html`, `terms.html`, and `styles.css`.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and the `/ (root)` folder, then save.

After GitHub publishes the site, use these addresses in Oura:

- Website: `https://YOUR_GITHUB_USERNAME.github.io/project-y/`
- Privacy Policy: `https://YOUR_GITHUB_USERNAME.github.io/project-y/privacy.html`
- Terms of Service: `https://YOUR_GITHUB_USERNAME.github.io/project-y/terms.html`
- Redirect URI for a local application: `http://localhost:8765/callback`
